@extends('layouts.admin')

@section('main-content')
    @if (session('success'))
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    @if (session('status'))
        <div class="alert alert-success border-left-success" role="alert">
            {{ session('status') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger border-left-danger" role="alert">
            <ul class="pl-4 my-2">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="card-header" style="font-weight: bold;">BARANGAY RESIDENT LIST</div>
        <div class="card-body">
            <div class="table table-responsive">
                <table class="table table-striped table-hover" id="example">
                    <thead>
                        <th>resident_image</th>
                        <th>first_name</th>
                        <th>middle_name</th>
                        <th>last_name</th>
                        <th>nickname</th>
                        <th>dob</th>
                        <th>civil_status</th>
                        <th>More Info</th>
                        {{-- <th>pwd</th>
                        <th>pwd_description</th>
                        <th>latitude</th>
                        <th>longitude</th>
                        <th>status</th>
                        <th>permanent_address</th>
                        <th>current_address</th> --}}
                    </thead>
                    <tbody>
                        @foreach ($residents as $data)
                            <tr>
                                <td>
                                    <a target="_blank" href="{{ url('admin_resident_show_map', ['id' => $data->id]) }}">
                                        <img src="{{ asset('/storage/' . $data->resident_image) }}"
                                            class="img img-thumbnail">
                                    </a>
                                </td>
                                <td>{{ $data->first_name }}</td>
                                <td>{{ $data->middle_name }}</td>
                                <td>{{ $data->last_name }}</td>
                                <td>{{ $data->nickname }}</td>
                                <td>
                                    @php
                                        
                                        $dateOfBirth = $data->dob;
                                        $today = date('Y-m-d');
                                        $diff = date_diff(date_create($dateOfBirth), date_create($today));
                                        echo $diff->format('%y') . ' years old';
                                    @endphp
                                </td>
                              
                                <td>{{ $data->civil_status }}</td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                                        data-target="#exampleModal_more_information{{ $data->id }}">
                                        Show
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal_more_information{{ $data->id }}" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-xl" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">{{ $data->first_name }}
                                                        {{ $data->middle_name }} {{ $data->last_name }}</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <table class="table table-striped table-hover table-sm">
                                                        <thead>
                                                            <tr>
                                                                <th>place_of_birth</th>
                                                                <th>sex</th>
                                                                <th>nationality</th>
                                                                <th>pwd</th>
                                                                <th>pwd_description</th>
                                                                <th>latitude</th>
                                                                <th>longitude</th>
                                                                <th>status</th>
                                                                <th>permanent_address</th>
                                                                <th>current_address</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>{{ $data->place_of_birth }}</td>
                                                                <td>{{ $data->sex }}</td>
                                                                <td>{{ $data->nationality }}</td>
                                                                <td>{{ $data->pwd }}</td>
                                                                <td>{{ $data->pwd_description }}</td>
                                                                <td>{{ $data->latitude }}</td>
                                                                <td>{{ $data->longitude }}</td>
                                                                <td>{{ $data->status }}</td>
                                                                <td>{{ $data->permanent_address }}</td>
                                                                <td>{{ $data->current_address }}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">Close</button>
                                                    {{-- <button type="button" class="btn btn-primary">Save changes</button> --}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

@endsection
