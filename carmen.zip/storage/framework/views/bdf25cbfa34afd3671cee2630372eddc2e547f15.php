<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-12">
                                <div class='container2'>
                                    <div>
                                        <img src='<?php echo e(asset('/img/carmen_logo.png')); ?>' class='iconDetails'>
                                    </div>
                                    <div style='margin-left:70px;margin-top:10px;'>
                                        <h4 style="text-transform: uppercase;text-align:center;">Residency of barangay
                                            inhabitants</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger border-left-danger" role="alert">
                                <ul class="pl-4 my-2">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('login')); ?>" class="user">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                            <label for="">Email</label>
                            <div class="input-group mb-1">
                                <input id="email" type="email"
                                    class="form-control rounded-0 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus
                                    aria-label="Username" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2"
                                        style="background-color:transparent;"><i class="bi bi-person-check-fill"></i></span>
                                </div>
                            </div>

                            <label>Password</label>
                            <div class="input-group mb-3">
                                <input id="password" type="password" required
                                    class="form-control rounded-0 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    autocomplete="new-password">
                                <div class="input-group-append">
                                    <span class="input-group-text" style="background-color: transparent"
                                        onclick="password_show_hide();">
                                        <i class="fas fa-eye" id="show_eye"></i>
                                        <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                                    </span>
                                </div>
                            </div>

                            

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary rounded-0 btn-block">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>
                        </form>

                        <hr>

                        <?php if(Route::has('password.request')): ?>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Password?')); ?>

                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(route('register')); ?>"><?php echo e(__('Create an Account!')); ?></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\carmen\resources\views/auth/login.blade.php ENDPATH**/ ?>