

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger border-left-danger" role="alert">
            <ul class="pl-4 my-2">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card" style="margin-bottom: 10px;">
        <div class="card-header" style="font-weight: bold;">BARANGAY COMPLAIN</div>
        <form action="<?php echo e(route('admin_complain_type_process')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <label>Complainant</label>
                        <select name="complainant_id" class="form-control rounded-0" required>
                            <option value="" default>Select</option>
                            <?php $__currentLoopData = $residents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?> <?php echo e($data->middle_name); ?>

                                    <?php echo e($data->last_name); ?> - <?php echo e($data->nickname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>Respondent</label>
                        <select name="complainant_id" class="form-control rounded-0" required>
                            <option value="" default>Select</option>
                            <?php $__currentLoopData = $residents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?> <?php echo e($data->middle_name); ?>

                                    <?php echo e($data->last_name); ?> - <?php echo e($data->nickname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="">Complain Type</label>
                        <select name="complain_type_id" class="form-control rounded-0" required>
                            <option value="" default>Select</option>
                            <?php $__currentLoopData = $complain_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->complain_type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="">Date of Hearing</label>
                        <input type="date" class="form-control" name="date_of_hearing" required>
                    </div>
                    <div class="col-md-4">
                        <label for="">Time</label>
                        <input type="time" class="form-control" name="time" required>
                    </div>
                    <div class="col-md-4">
                        <label for="">Lupon</label>
                        <select name="lupon" class="form-control rounded-0" required>
                            <option value="" default>Select</option>
                            <?php $__currentLoopData = $lupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?> <?php echo e($data->last_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <label for="">Reason</label>
                        <textarea name="Reason" class="form-control rounded-0" name="reason"></textarea>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <button class="btn btn-sm float-right btn-primary">Save</button>
            </div>
        </form>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\carmen\resources\views/complain.blade.php ENDPATH**/ ?>