

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger border-left-danger" role="alert">
            <ul class="pl-4 my-2">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header" style="font-weight: bold;">BARANGAY RESIDENT REGISTRATION</div>
        <form action="<?php echo e(route('admin_register_residents_process')); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <label>Latitude</label>
                        <input type="text" class="form-control rounded-0" name="latitude" id="latitude">
                    </div>
                    <div class="col-md-6">
                        <label>Longitude</label>
                        <input type="text" class="form-control rounded-0" name="longitude" id="longitude">
                    </div>
                </div>
                <br />
                
                <div class="row">
                    <div class="col-md-3">
                        <label style="font-weight: bold;">Personal Information</label>
                        <img id="blah" src="<?php echo e(asset('carmen_images/default_image.jpg')); ?>" class="img img-thumbnail"
                            alt="your image" />
                        <input accept="image/*" name="resident_image" class="form-control" type='file' id="imgInp" />
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <label>First Name</label>
                        <input type="text" name="first_name" placeholder="First Name" class="form-control rounded-0"
                            required>
                    </div>
                    <div class="col-md-3">
                        <label>Middle Name</label>
                        <input type="text" placeholder="Middle Name" name="middle_name" class="form-control rounded-0"
                            required>
                    </div>
                    <div class="col-md-3">
                        <label>Last Name</label>
                        <input type="text" placeholder="Last Name" id="last_name" name="last_name"
                            class="form-control rounded-0" required>
                    </div>
                    <div class="col-md-3">
                        <label>Nickname</label>
                        <input type="text" placeholder="Nickname" id="nickname" name="nickname"
                            class="form-control rounded-0" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <label>Current Address</label>
                        <input type="text" class="form-control" required name="current_address">
                    </div>
                    <div class="col-md-12">
                        <label>Permanent Address</label>
                        <input type="text" class="form-control" required name="permanent_address">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <label>Zone</label>
                        <select name="zone" class="form-control rounded-0">
                            <option value="" default>Select</option>
                            <option value="Zone 1">Zone 1</option>
                            <option value="Zone 2">Zone 2</option>
                            <option value="Zone 3">Zone 3</option>
                            <option value="Zone 4">Zone 4</option>
                            <option value="Zone 5">Zone 5</option>
                            <option value="Zone 6">Zone 6</option>
                            <option value="Zone 7">Zone 7</option>
                            <option value="Zone 8">Zone 8</option>
                            <option value="Zone 9">Zone 9</option>
                            <option value="Zone 10">Zone 10</option>
                            <option value="Zone 11">Zone 11</option>
                            <option value="Zone 12">Zone 12</option>
                            <option value="Zone 13">Zone 13</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>Date of birth</label>
                        <input type="date" name="dob" class="form-control rounded-0" required>
                    </div>
                    <div class="col-md-3">
                        <label>Place of birth</label>
                        <input type="text" id="place_of_birth" name="place_of_birth" class="form-control rounded-0"
                            required>
                    </div>
                    <div class="col-md-3">
                        <label>Sex</label>
                        <select name="sex" class="form-control rounded-0" required>
                            <option value="" default>Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="LGBTQ">LGBTQ</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>Nationality</label>
                        <input type="text" name="nationality" class="form-control rounded-0" required>
                    </div>
                    <div class="col-md-4">
                        <label>Civil Status</label>
                        <select name="civil_status" class="form-control rounded-0" required>
                            <option value="" default>Select</option>
                            <option value="Single">Single</option>
                            <option value="Married">Married</option>
                            <option value="Widowed">Widowed</option>
                            <option value="Divorced">Divorced</option>
                            <option value="Separated">Separated</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>PWD</label>
                        <select name="pwd" id="pwd" class="form-control rounded-0" required>
                            <option value="" default>Select</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div class="col-md-12" style="display: none" id="show_trigger">
                        <label>PWD Description</label>
                        <textarea name="pwd_description" id="pwd_description" class="form-control rounded-0"></textarea>
                    </div>
                </div>
                
            </div>
            <div class="card-footer">
                <button class="btn btn-sm float-right btn-primary" type="submit"
                    style="margin-bottom: 10px;">Submit</button>
                
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\carmen\resources\views/admin_register_residents.blade.php ENDPATH**/ ?>