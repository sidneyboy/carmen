<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Laravel SB Admin 2">
    <meta name="author" content="Alejandro RH">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>ROBI</title>

    <!-- Fonts -->
    <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/sb-admin-2.min.css')); ?>" rel="stylesheet">

    <!-- Favicon -->
    <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon" type="image/png">

    <style>
        h2 {
            width: 100%;
            text-align: center;
            border-bottom: 3px solid #000;
            line-height: 0.1em;
            margin: 10px 0 20px;
            font-size: 20px;
        }

        h2 span {
            background: #fff;
            padding: 0 10px;
        }
    </style>
</head>

<body id="page-top" onload="getLocation()">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-text">BRGY CARMEN-ROBI</div>
            </a>
            <?php if($user->user_type == 'Super_user'): ?>
                <!-- Divider -->
                <hr class="sidebar-divider my-0">

                <!-- Nav Item - Dashboard -->
                <li class="nav-item <?php echo e(Nav::isRoute('home')); ?>">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        <span><?php echo e(__('Dashboard')); ?></span></a>
                </li>

                <!-- Divider -->
                <hr class="sidebar-divider">

                <!-- Heading -->
                <div class="sidebar-heading">
                    Functions
                </div>

                <!-- Nav Item - Profile -->


                <li class="nav-item <?php echo e(Nav::isRoute('admin_barangay_officials_registration')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin_barangay_officials_registration')); ?>">
                        <i class="fas fa-fw fa-user"></i>
                        <span><?php echo e(__('BRGY Officials Reg')); ?></span>
                    </a>
                </li>
            <?php elseif($user->user_type == 'Monitoring'): ?>
                <div class="sidebar-heading">
                    Functions
                </div>

                <li class="nav-item <?php echo e(Nav::isRoute('admin_register_residents')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin_register_residents')); ?>">
                        <i class="fas fa-fw fa-user"></i>
                        <span><?php echo e(__('BRGY Resident Reg')); ?></span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(Nav::isRoute('admin_resident_list')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin_resident_list')); ?>">
                        <i class="fas fa-fw fa-user"></i>
                        <span><?php echo e(__('BRGY Resident List')); ?></span>
                    </a>
                </li>
            <?php elseif($user->user_type == 'Lupon'): ?>
                <li class="nav-item <?php echo e(Nav::isRoute('admin_add_complain_type')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin_add_complain_type')); ?>">
                        <i class="fas fa-fw fa-user"></i>
                        <span><?php echo e(__('BRGY Complain Type')); ?></span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(Nav::isRoute('complain')); ?>">
                    <a class="nav-link" href="<?php echo e(route('complain')); ?>">
                        <i class="fas fa-fw fa-user"></i>
                        <span><?php echo e(__('BRGY Complain')); ?></span>
                    </a>
                </li>
            <?php endif; ?>



            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span
                                    class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->name); ?></span>
                                <figure class="img-profile rounded-circle avatar font-weight-bold"
                                    data-initial="<?php echo e(Auth::user()->name[0]); ?>"></figure>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(__('Profile')); ?>

                                </a>
                                <a class="dropdown-item" href="javascript:void(0)">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(__('Settings')); ?>

                                </a>
                                <a class="dropdown-item" href="javascript:void(0)">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(__('Activity Log')); ?>

                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(__('Logout')); ?>

                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <?php echo $__env->yieldContent('main-content'); ?>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Alejandro RH <?php echo e(now()->year); ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Ready to Leave?')); ?></h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-link" type="button" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sb-admin-2.min.js')); ?>"></script>

    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function() {
            $('#example').DataTable({
                // dom: 'Bfrtip',
                // buttons: [
                //     'excel',
                // ]
            });
        });


        $("#family_name").keyup(function() {
            $('#father_last_name').val($('#family_name').val());
        });

        $("#pwd").change(function() {
            if ($(this).val() == 'Yes') {
                $('#show_trigger').show();
            } else {
                $('#show_trigger').hide();
            }
        });

        $("#mother_pwd").change(function() {
            if ($(this).val() == 'Yes') {
                $('#mother_show_trigger').show();
            } else {
                $('#mother_show_trigger').hide();
            }
        });



        $("#ethnic_origin").click(function() {
            if ($(this).val() == 'Others') {
                $('#show_other_ethnic_if_trigger').show();
            } else {
                $('#show_other_ethnic_if_trigger').hide();
            }
        });

        // $("#registration_proceed").click(function() {
        //     var number_of_childrens = $('#number_of_childrens').val();
        //     $.post({
        //         type: "POST",
        //         url: "/admin_registration_residents_generate_number_of_childrens",
        //         data: 'number_of_childrens=' + number_of_childrens,
        //         success: function(data) {
        //             console.log(data);
        //             $('#show_personnal_information').html(data);
        //         },
        //         error: function(error) {
        //             console.log(error);
        //         }
        //     });
        // });

        imgInp.onchange = evt => {
            const [file] = imgInp.files
            if (file) {
                blah.src = URL.createObjectURL(file)
            }
        }

        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition);
            } else {
                x.innerHTML = "Geolocation is not supported by this browser.";
            }
        }

        function showPosition(position) {
            $('#latitude').val(position.coords.latitude);
            $('#longitude').val(position.coords.longitude);
        }
    </script>

</body>

</html>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\carmen\resources\views/layouts/admin.blade.php ENDPATH**/ ?>