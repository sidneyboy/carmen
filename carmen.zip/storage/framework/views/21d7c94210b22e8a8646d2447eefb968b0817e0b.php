

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header" style="font-weight: bold;">BARANGAY OFFICIALS USER TYPE</div>
                <div class="card-body">
                    <div class="form-group">
                        <label>User Type</label>
                        <input type="text" class="form-control rounded-0" required name="user_type">
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-sm float-right btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\carmen\resources\views/admin_user_type.blade.php ENDPATH**/ ?>