

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger border-left-danger" role="alert">
            <ul class="pl-4 my-2">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header" style="font-weight: bold;">BARANGAY OFFICIALS REGISTRATION</div>
        <form action="<?php echo e(route('admin_barangay_officials_registration_process')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <label>First Name</label>
                        <input type="text" class="form-control rounded-0" value="<?php echo e(old('name')); ?>" name="name"
                            required>
                    </div>
                    <div class="col-md-4">
                        <label>Middle Name</label>
                        <input type="text" class="form-control rounded-0" value="<?php echo e(old('middle_name')); ?>"
                            name="middle_name" required>
                    </div>
                    <div class="col-md-4">
                        <label>Last Name</label>
                        <input type="text" class="form-control rounded-0" value="<?php echo e(old('last_name')); ?>" name="last_name"
                            required>
                    </div>
                    <div class="col-md-4">
                        <label>Gender</label>
                        <select class="form-control rounded-0" value="<?php echo e(old('gender')); ?>" name="gender" required>
                            <option value="" default>Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Rather Not Say">Rather Not Say</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label>DOB</label>
                        <input type="date" class="form-control rounded-0" value="<?php echo e(old('date_of_birth')); ?>"
                            name="dob" required>
                    </div>

                    <div class="col-md-4">
                        <label>User Type</label>
                        <select class="form-control rounded-0" name="user_type" required>
                            <option value="" default>Select</option>
                            <option value="Admin">Admin</option>
                            <option value="Monitoring">Monitoring</option>
                            <option value="Lupon">Lupon</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label>Email</label>
                        <input type="email" class="form-control rounded-0" value="<?php echo e(old('email')); ?>" name="email"
                            required>
                    </div>

                    <div class="col-md-4">
                        <label>Password</label>
                        <input type="password" class="form-control rounded-0" name="password" required>
                    </div>

                    <div class="col-md-4">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control rounded-0" name="password_confirmation" required>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <button class="btn btn-sm float-right btn-primary">Save</button>
            </div>
        </form>
    </div>
    <br />
    <div class="card">
        <div class="card-header" style="font-weight:bold;">User List</div>
        <div class="card-body">
            <table class="table table-striped table-hover" id="example">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>DOB / Age</th>
                        <th>User Type</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->name); ?> <?php echo e($data->middle_name); ?> <?php echo e($data->last_name); ?></td>
                            <td><?php echo e($data->gender); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td>
                                <?php

                                    $dateOfBirth = $data->dob;
                                    $today = date('Y-m-d');
                                    $diff = date_diff(date_create($dateOfBirth), date_create($today));
                                    echo $data->dob ." / ". $diff->format('%y');
                                ?>
                            </td>
                            <td><?php echo e($data->user_type); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\carmen\resources\views/admin_barangay_officials_registration.blade.php ENDPATH**/ ?>