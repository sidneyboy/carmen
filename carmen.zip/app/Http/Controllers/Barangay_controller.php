<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Residents;
use App\Models\Complain_type;
use Illuminate\Http\Request;

class Barangay_controller extends Controller
{
    public function admin_dashboard()
    {
        $user = User::find(auth()->user()->id);

        if ($user->user_type == 'Super_user') {
            return view('admin_dashboard', [
                'user' => $user,
            ]);
        } elseif ($user->user_type == 'Monitoring') {
            return view('admin_register_residents', [
                'user' => $user,
            ]);
        } else if ($user->user_type == 'Lupon') {
            return view('admin_add_complain_type', [
                'user' => $user,
            ]);
        }
    }

    public function admin_user_type()
    {
        return view('admin_user_type');
    }

    public function admin_barangay_officials_registration()
    {
        $user = User::find(auth()->user()->id);
        $user_list = User::where('id', '!=', auth()->user()->id)->get();
        return view('admin_barangay_officials_registration', [
            'user_list' => $user_list,
            'user' => $user,
        ]);
    }

    public function admin_barangay_officials_registration_process(Request $request)
    {
        // return $request->input();
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'middle_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'user_type' => ['required', 'string'],
            'gender' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $new_user = new User([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'user_type' => $request->input('user_type'),
            'middle_name' => $request->input('middle_name'),
            'last_name' => $request->input('last_name'),
            'gender' => $request->input('gender'),
            'dob' => $request->input('dob'),
        ]);

        $new_user->save();

        return redirect()->route('admin_barangay_officials_registration')->with('success', 'Success');
    }

    public function admin_register_residents()
    {
        $user = User::find(auth()->user()->id);
        return view('admin_register_residents', [
            'user' => $user,
        ]);
    }

    public function admin_registration_residents_generate_number_of_childrens(Request $request)
    {
        //return $request->input();
        return view('admin_registration_residents_generate_number_of_childrens')
            ->with('number_of_childrens', $request->input('number_of_childrens'));
    }

    public function admin_register_residents_process(Request $request)
    {
        // dd($request->all());

        $resident_image = $request->file('resident_image');
        $resident_image_name = 'resident_image-' . time() . '.' . $resident_image->getClientOriginalExtension();
        $path_resident_image = $resident_image->storeAs('public', $resident_image_name);


        $new_residents = new Residents([
            'first_name' => $request->input('first_name'),
            'middle_name' => $request->input('middle_name'),
            'last_name' => $request->input('last_name'),
            'nickname' => $request->input('nickname'),
            'dob' => $request->input('dob'),
            'place_of_birth' => $request->input('place_of_birth'),
            'zone' => $request->input('zone'),
            'sex' => $request->input('sex'),
            'nationality' => $request->input('nationality'),
            'civil_status' => $request->input('civil_status'),
            'pwd' => $request->input('pwd'),
            'pwd_description' => $request->input('pwd_description'),
            'latitude' => $request->input('longitude'),
            'longitude' => $request->input('latitude'),
            'resident_image' => $resident_image_name,
            'status' => $request->input('status'),
            'permanent_address' => $request->input('permanent_address'),
            'current_address' => $request->input('current_address'),
        ]);

        $new_residents->save();


        return redirect()->route('admin_register_residents')->with('success', 'Success');
    }

    public function admin_resident_list()
    {
        $user = User::find(auth()->user()->id);
        $residents = Residents::get();
        return view('admin_resident_list', [
            'user' => $user,
            'residents' => $residents,
        ]);
    }

    public function admin_resident_show_map($id)
    {
        $residents = Residents::find($id);
        $user = User::find(auth()->user()->id);

        return view('admin_resident_show_map', [
            'residents' => $residents,
            'user' => $user,
        ]);
    }

    public function admin_add_complain_type()
    {
        $user = User::find(auth()->user()->id);
        $complain_type = Complain_type::get();
        return view('admin_add_complain_type', [
            'user' => $user,
            'complain_type' => $complain_type,
        ]);
    }

    public function admin_complain_type_process(Request $request)
    {
        $new = new Complain_type([
            'complain_type' => $request->input('complain_type'),
        ]);

        $new->save();
        return redirect()->route('admin_add_complain_type')->with('success', 'Success');
    }

    public function complain_type_edit(Request $request)
    {
        Complain_type::where('id', $request->input('complain_id'))
            ->update(['complain_type' => $request->input('complain_type')]);

        return redirect()->route('admin_add_complain_type')->with('success', 'Success');
    }

    public function complain()
    {
        $user = User::find(auth()->user()->id);
        $residents = Residents::get();
        $complain_type = Complain_type::get();
        $lupon = User::where('user_type', 'Lupon')->get();
        return view('complain', [
            'user' => $user,
            'residents' => $residents,
            'complain_type' => $complain_type,
            'lupon' => $lupon,
        ]);
    }
}
