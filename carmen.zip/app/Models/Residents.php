<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Residents extends Model
{
    use HasFactory;

    protected $fillable = [
       'first_name',
       'middle_name',
       'last_name',
       'nickname',
       'dob',
       'place_of_birth',
       'sex',
       'nationality',
       'civil_status',
       'pwd',
       'pwd_description',
       'latitude',
       'longitude',
       'resident_image',
       'status',
       'permanent_address',
       'current_address',
       'zone',
    ];
}
